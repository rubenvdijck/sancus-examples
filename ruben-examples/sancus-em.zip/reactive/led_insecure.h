#ifndef __LED_INSECURE_H__
#define __LED_INSECURE_H__

void led_insecure_toggle(int state);

#endif
