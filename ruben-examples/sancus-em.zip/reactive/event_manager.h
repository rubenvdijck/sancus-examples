#ifndef __EVENT_MANAGER_H__
#define __EVENT_MANAGER_H__

#include "thread.h"

void event_manager_run(kernel_pid_t uart_pid);

#endif
