#ifndef __BUTTON_DRIVER_H__
#define __BUTTON_DRIVER_H__

#if USE_MMIO_BTN
  #include <sancus/sm_support.h>

  extern struct SancusModule button_driver;
#endif

#endif
